package com.example.lista_tarefas

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
