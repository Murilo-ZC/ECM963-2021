import 'package:flutter/material.dart';

void main() {
  runApp(MinhaLista());
}

class MinhaLista extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "Aplicativo de Lista",
      home: MinhaTela(),
    );
  }
}

class MinhaTela extends StatefulWidget {
  @override
  _MinhaTelaState createState() => _MinhaTelaState();
}

class _MinhaTelaState extends State<MinhaTela> {
  var _tarefaController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Minha Lista de Tarefas"),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextField(
                controller: _tarefaController,
                decoration: InputDecoration(hintText: "Informe a tarefa"),
              ),
            ),
            ElevatedButton(
              onPressed: () {},
              child: Text("Adicionar tarefa"),
            ),
          ],
        ),
      ),
    );
  }
}
