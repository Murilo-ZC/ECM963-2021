class Item {
  bool _estado;
  String _descricao;

  Item(this._estado, this._descricao);
}
